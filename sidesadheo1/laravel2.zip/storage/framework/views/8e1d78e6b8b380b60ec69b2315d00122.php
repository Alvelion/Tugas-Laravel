<!-- Modal -->
<div class="modal fade" id="detailAccount-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="detailAccountLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title fs-5" id="detailAccountLabel">Detail Akun</h4>
        <button type="button" class="btn btn-default" data-bs-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group mb-3">
          <label for="name">Nama</label>
          <input type="text" name="name" class="form-control" value="<?php echo e($item->user->name); ?>" readonly>
        </div>
        <div class="form-group mb-3">
          <label for="email">Email</label>
          <input type="email" name="email" class="form-control" value="<?php echo e($item->user->email); ?>" readonly>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\DesaAryatama\resources\views/pages/resident/detail-account.blade.php ENDPATH**/ ?>