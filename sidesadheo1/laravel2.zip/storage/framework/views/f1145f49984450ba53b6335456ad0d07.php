<footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; M.Aryatama <?php echo e(date('Y')); ?></span>
                    </div>
                </div>
            </footer><?php /**PATH C:\xampp\htdocs\DesaAryatama\resources\views/layouts/footer.blade.php ENDPATH**/ ?>