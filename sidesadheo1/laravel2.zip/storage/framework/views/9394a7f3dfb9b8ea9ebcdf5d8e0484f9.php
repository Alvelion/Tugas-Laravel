

<?php $__env->startSection('content'); ?>
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Permintaan Akun DesaLink</h1>
                    </div>

                    <?php if(session('success')): ?>
                        <script>
                            Swal.fire({
                                title: "Proceeded",
                                text: "<?php echo e(session()->get('success')); ?>",
                                icon: "success"
                            });
                        </script>
                    <?php endif; ?>

                    
                    <div class="row">
                        <div class="col">
                            <div class="card shadow">
                                <div class="card-body">
                                    <div style="overflow-x: auto;">
                                        <table class="table table-bordered table-hovered" style="min-width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>No</th>                   
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <?php if(count($users) < 1): ?>
                                                <tbody>
                                                    <tr>
                                                        <td colspan="11">
                                                            <p class="pt-3 text-center">Tidak ada Data Penduduk</p>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            <?php else: ?>
                                                <tbody>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration + $users->firstItem() - 1); ?></td>
                                                        <td><?php echo e($item->name); ?></td>
                                                        <td><?php echo e($item->email); ?></td>
                                                        <td>
                                                            <div class="d-flex" style="gap: 10px;">
                                                                <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#confirmationReject-<?php echo e($item->id); ?>">
                                                                    Reject
                                                                </button>
                                                                <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#confirmationApprove-<?php echo e($item->id); ?>">
                                                                    Accept
                                                                </button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                        <?php echo $__env->make('pages.account-request.confirmation-approve', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                        <?php echo $__env->make('pages.account-request.confirmation-reject', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            <?php endif; ?>
                                        </table>
                                    </div>
                                </div>
                                <?php if($users->lastPage() > 1): ?>
                                <div class="card-footer">
                                    <?php echo e($users->links('pagination::bootstrap-5')); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\DesaAryatama\resources\views/pages/account-request/index.blade.php ENDPATH**/ ?>