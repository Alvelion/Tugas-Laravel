<!-- Modal -->
<div class="modal fade" id="confirmationApprove-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="confirmationApproveLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="/account-request/approval/<?php echo e($item->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title fs-5" id="confirmationApproveLabel">Konfirmasi Setuju</h4>
        <button type="button" class="btn btn-default" data-bs-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="for" value="approve">
        <span>Apakah anda yakin ingin menyetujui akun ini?</span>
        <div class="form-group mt-3">
            <label for="resident_id">Pilih Penduduk</label> 
            <select name="resident_id" id="resident_id" class="form-control">
                <option value="">None</option>
                <?php $__currentLoopData = $residents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-success">Accept</button>
      </div>
    </div>
    </form>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\DesaAryatama\resources\views/pages/account-request/confirmation-approve.blade.php ENDPATH**/ ?>